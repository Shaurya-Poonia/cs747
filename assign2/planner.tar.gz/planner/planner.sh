#/bin/bash
python value_Iteration.py $1

