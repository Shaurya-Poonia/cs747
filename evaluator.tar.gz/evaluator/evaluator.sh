#/bin/bash
python evaluator.py $1

